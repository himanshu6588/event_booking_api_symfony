<?php

namespace App\Repository;

use App\Entity\Event;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Event>
 */
class EventRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Event::class);
    }

    public function findByFilters(array $filters = [], array $orderBy = null, int $limit = null, int $offset = null): array
    {
        $qb = $this->createQueryBuilder('e');

        foreach ($filters as $field => $value) {
            if (is_array($value) && count($value) === 2) {
                // Handle operators like >=, <=, etc.
                $operator = $value[0];
                $filterValue = $value[1];
                $qb->andWhere("e.$field $operator :$field")
                   ->setParameter($field, $filterValue);
            } else {
                $qb->andWhere("e.$field = :$field")
                   ->setParameter($field, $value);
            }
        }

        if ($orderBy) {
            foreach ($orderBy as $field => $direction) {
                $qb->addOrderBy("e.$field", $direction);
            }
        }

        if ($limit) {
            $qb->setMaxResults($limit);
        }

        if ($offset) {
            $qb->setFirstResult($offset);
        }

        return $qb->getQuery()->getResult();
    }

    public function countByFilters(array $filters = []): int
    {
        $qb = $this->createQueryBuilder('e')
            ->select('COUNT(e.id)');

        foreach ($filters as $field => $value) {
            if (is_array($value) && count($value) === 2) {
                // Handle operators like >=, <=, etc.
                $operator = $value[0];
                $filterValue = $value[1];
                $qb->andWhere("e.$field $operator :$field")
                   ->setParameter($field, $filterValue);
            } else {
                $qb->andWhere("e.$field = :$field")
                   ->setParameter($field, $value);
            }
        }

        return (int) $qb->getQuery()->getSingleScalarResult();
    }
}