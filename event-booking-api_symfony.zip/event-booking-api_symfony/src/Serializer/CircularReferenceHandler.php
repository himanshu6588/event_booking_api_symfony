<?php

namespace App\Serializer;

use App\Entity\Attendee;
use App\Entity\Booking;
use App\Entity\Event;

class CircularReferenceHandler
{
    public function __invoke($object)
    {
        if ($object instanceof Event) {
            return $object->getId();
        }
        
        if ($object instanceof Attendee) {
            return $object->getId();
        }
        
        if ($object instanceof Booking) {
            return $object->getId();
        }
        
        return null;
    }
}