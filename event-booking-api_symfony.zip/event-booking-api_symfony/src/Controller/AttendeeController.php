<?php

namespace App\Controller;

use App\Entity\Attendee;
use App\Repository\AttendeeRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/api/attendees')]
class AttendeeController extends AbstractController
{
    public function __construct(
        private EntityManagerInterface $entityManager,
        private SerializerInterface $serializer,
        private ValidatorInterface $validator
    ) {}

    #[Route('', methods: ['GET'])]
    public function index(Request $request, AttendeeRepository $repository): Response
    {
        $page = $request->query->getInt('page', 1);
        $limit = $request->query->getInt('limit', 10);

        $attendees = $repository->findBy(
            [],
            ['lastName' => 'ASC', 'firstName' => 'ASC'],
            $limit,
            ($page - 1) * $limit
        );

        $total = $repository->count([]);

        return $this->json([
            'data' => $attendees,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'totalPages' => ceil($total / $limit)
        ]);
    }

    #[Route('/{id}', methods: ['GET'], requirements: ['id' => '\d+'])]
    public function show(Attendee $attendee): Response
    {
        return $this->json($attendee);
    }

    #[Route('', methods: ['POST'])]
    public function create(Request $request): Response
    {
        $attendee = $this->serializer->deserialize(
            $request->getContent(),
            Attendee::class,
            'json'
        );

        $errors = $this->validator->validate($attendee);
        if (count($errors) > 0) {
            return $this->json(['errors' => (string) $errors], Response::HTTP_BAD_REQUEST);
        }

        $this->entityManager->persist($attendee);
        $this->entityManager->flush();

        return $this->json($attendee, Response::HTTP_CREATED);
    }

    #[Route('/{id}', methods: ['PUT'], requirements: ['id' => '\d+'])]
    public function update(Request $request, Attendee $attendee): Response
    {
        $this->serializer->deserialize(
            $request->getContent(),
            Attendee::class,
            'json',
            ['object_to_populate' => $attendee]
        );

        $errors = $this->validator->validate($attendee);
        if (count($errors) > 0) {
            return $this->json(['errors' => (string) $errors], Response::HTTP_BAD_REQUEST);
        }

        $this->entityManager->flush();

        return $this->json($attendee);
    }

    #[Route('/{id}', methods: ['DELETE'], requirements: ['id' => '\d+'])]
    public function delete(Attendee $attendee): Response
    {
        // Check if the attendee has bookings
        if (!$attendee->getBookings()->isEmpty()) {
            return $this->json(
                ['error' => 'Cannot delete an attendee with existing bookings'],
                Response::HTTP_BAD_REQUEST
            );
        }

        $this->entityManager->remove($attendee);
        $this->entityManager->flush();

        return $this->json(null, Response::HTTP_NO_CONTENT);
    }
}