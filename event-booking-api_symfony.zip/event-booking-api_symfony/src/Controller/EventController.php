<?php

namespace App\Controller;

use App\Entity\Event;
use App\Repository\EventRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/api/events')]
class EventController extends AbstractController
{
    public function __construct(
        private EntityManagerInterface $entityManager,
        private SerializerInterface $serializer,
        private ValidatorInterface $validator
    ) {}

    #[Route('', methods: ['GET'])]
    public function index(Request $request, EventRepository $repository): Response
    {
        $page = $request->query->getInt('page', 1);
        $limit = $request->query->getInt('limit', 10);
        
        // Add filtering options
        $filters = [];
        if ($request->query->has('country')) {
            $filters['country'] = $request->query->get('country');
        }
        
        if ($request->query->has('future_only') && $request->query->getBoolean('future_only')) {
            $filters['eventDate'] = ['>=', new \DateTime()];
        }

        $events = $repository->findByFilters(
            $filters,
            ['eventDate' => 'ASC'],
            $limit,
            ($page - 1) * $limit
        );
        
        $total = $repository->countByFilters($filters);

        return $this->json([
            'data' => $events,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'totalPages' => ceil($total / $limit)
        ]);
    }

    #[Route('/{id}', methods: ['GET'], requirements: ['id' => '\d+'])]
    public function show(Event $event): Response
    {
        return $this->json($event);
    }

    #[Route('', methods: ['POST'])]
    public function create(Request $request): Response
    {
        $event = $this->serializer->deserialize(
            $request->getContent(),
            Event::class,
            'json'
        );

        $errors = $this->validator->validate($event);
        if (count($errors) > 0) {
            return $this->json(['errors' => (string) $errors], Response::HTTP_BAD_REQUEST);
        }

        $this->entityManager->persist($event);
        $this->entityManager->flush();

        return $this->json($event, Response::HTTP_CREATED);
    }

    #[Route('/{id}', methods: ['PUT'], requirements: ['id' => '\d+'])]
    public function update(Request $request, Event $event): Response
    {
        $this->serializer->deserialize(
            $request->getContent(),
            Event::class,
            'json',
            ['object_to_populate' => $event]
        );

        $errors = $this->validator->validate($event);
        if (count($errors) > 0) {
            return $this->json(['errors' => (string) $errors], Response::HTTP_BAD_REQUEST);
        }

        $this->entityManager->flush();

        return $this->json($event);
    }

    #[Route('/{id}', methods: ['DELETE'], requirements: ['id' => '\d+'])]
    public function delete(Event $event): Response
    {
        // Check if the event has bookings
        if (!$event->getBookings()->isEmpty()) {
            return $this->json(
                ['error' => 'Cannot delete an event with existing bookings'],
                Response::HTTP_BAD_REQUEST
            );
        }

        $this->entityManager->remove($event);
        $this->entityManager->flush();

        return $this->json(null, Response::HTTP_NO_CONTENT);
    }
}