<?php

namespace App\Controller;

use App\Entity\Attendee;
use App\Entity\Booking;
use App\Entity\Event;
use App\Repository\BookingRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/api/bookings')]
class BookingController extends AbstractController
{
    public function __construct(
        private EntityManagerInterface $entityManager,
        private SerializerInterface $serializer,
        private ValidatorInterface $validator
    ) {}

    #[Route('', methods: ['GET'])]
    public function index(Request $request, BookingRepository $repository): Response
    {
        $page = $request->query->getInt('page', 1);
        $limit = $request->query->getInt('limit', 10);

        $filters = [];
        if ($request->query->has('event_id')) {
            $filters['event'] = $request->query->getInt('event_id');
        }
        if ($request->query->has('attendee_id')) {
            $filters['attendee'] = $request->query->getInt('attendee_id');
        }

        $bookings = $repository->findBy(
            $filters,
            ['bookedAt' => 'DESC'],
            $limit,
            ($page - 1) * $limit
        );

        $total = $repository->count($filters);

        return $this->json([
            'data' => $bookings,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'totalPages' => ceil($total / $limit)
        ]);
    }

    #[Route('/{id}', methods: ['GET'], requirements: ['id' => '\d+'])]
    public function show(Booking $booking): Response
    {
        return $this->json($booking);
    }

    #[Route('', methods: ['POST'])]
    public function create(Request $request): Response
    {
        $data = json_decode($request->getContent(), true);
        
        if (!isset($data['event_id']) || !isset($data['attendee_id'])) {
            return $this->json(
                ['error' => 'Missing required fields: event_id and attendee_id'],
                Response::HTTP_BAD_REQUEST
            );
        }

        $event = $this->entityManager->getRepository(Event::class)->find($data['event_id']);
        if (!$event) {
            return $this->json(['error' => 'Event not found'], Response::HTTP_NOT_FOUND);
        }

        $attendee = $this->entityManager->getRepository(Attendee::class)->find($data['attendee_id']);
        if (!$attendee) {
            return $this->json(['error' => 'Attendee not found'], Response::HTTP_NOT_FOUND);
        }

        // Check if the event is already full
        if ($event->isFull()) {
            return $this->json(
                ['error' => 'This event is already at full capacity'],
                Response::HTTP_BAD_REQUEST
            );
        }

        // Check if the attendee has already booked this event
        $existingBooking = $this->entityManager->getRepository(Booking::class)->findOneBy([
            'event' => $event,
            'attendee' => $attendee
        ]);

        if ($existingBooking) {
            return $this->json(
                ['error' => 'This attendee has already booked this event'],
                Response::HTTP_BAD_REQUEST
            );
        }

        $booking = new Booking();
        $booking->setEvent($event);
        $booking->setAttendee($attendee);

        $errors = $this->validator->validate($booking);
        if (count($errors) > 0) {
            return $this->json(['errors' => (string) $errors], Response::HTTP_BAD_REQUEST);
        }

        $this->entityManager->persist($booking);
        $this->entityManager->flush();

        return $this->json($booking, Response::HTTP_CREATED);
    }

    #[Route('/{id}', methods: ['DELETE'], requirements: ['id' => '\d+'])]
    public function delete(Booking $booking): Response
    {
        $this->entityManager->remove($booking);
        $this->entityManager->flush();

        return $this->json(null, Response::HTTP_NO_CONTENT);
    }
}