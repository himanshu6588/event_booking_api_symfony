<?php

namespace App\DataFixtures;

use App\Entity\Attendee;
use App\Entity\Booking;
use App\Entity\Event;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        // Create events
        $events = [];
        for ($i = 1; $i <= 10; $i++) {
            $event = new Event();
            $event->setTitle('Event ' . $i);
            $event->setDescription('Description for event ' . $i);
            $event->setEventDate(new \DateTime('+' . $i . ' days'));
            $event->setCountry(['US', 'UK', 'FR', 'DE', 'JP'][$i % 5]);
            $event->setCapacity(50 + ($i * 10));
            
            $manager->persist($event);
            $events[] = $event;
        }

        // Create attendees
        $attendees = [];
        $firstNames = ['John', 'Jane', 'Bob', 'Alice', 'Charlie', 'Diana', 'Edward', 'Fiona'];
        $lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Wilson'];
        
        for ($i = 0; $i < 20; $i++) {
            $attendee = new Attendee();
            $firstName = $firstNames[$i % count($firstNames)];
            $lastName = $lastNames[$i % count($lastNames)];
            $attendee->setFirstName($firstName);
            $attendee->setLastName($lastName);
            $attendee->setEmail(strtolower($firstName . '.' . $lastName . $i . '@example.com'));
            
            $manager->persist($attendee);
            $attendees[] = $attendee;
        }

        // Create some bookings
        for ($i = 0; $i < 30; $i++) {
            $event = $events[$i % count($events)];
            $attendee = $attendees[$i % count($attendees)];
            
            // Check if this attendee already booked this event
            $alreadyBooked = false;
            foreach ($event->getBookings() as $booking) {
                if ($booking->getAttendee() === $attendee) {
                    $alreadyBooked = true;
                    break;
                }
            }
            
            // Check if the event is full
            if (!$alreadyBooked && !$event->isFull()) {
                $booking = new Booking();
                $booking->setEvent($event);
                $booking->setAttendee($attendee);
                
                $manager->persist($booking);
            }
        }

        $manager->flush();
    }
}