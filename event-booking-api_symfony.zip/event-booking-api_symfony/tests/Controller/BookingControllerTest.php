<?php

namespace App\Tests\Controller;

use App\Entity\Attendee;
use App\Entity\Event;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;
use Symfony\Component\HttpFoundation\Response;

class BookingControllerTest extends WebTestCase
{
    private $entityManager;
    private $event;
    private $attendee;

    protected function setUp(): void
    {
        $kernel = self::bootKernel();
        $this->entityManager = $kernel->getContainer()
            ->get('doctrine')
            ->getManager();

        // Create a test event
        $this->event = new Event();
        $this->event->setTitle('Test Event');
        $this->event->setDescription('Test Description');
        $this->event->setEventDate(new \DateTime('+1 day'));
        $this->event->setCountry('US');
        $this->event->setCapacity(2);
        
        // Create a test attendee
        $this->attendee = new Attendee();
        $this->attendee->setFirstName('John');
        $this->attendee->setLastName('Doe');
        $this->attendee->setEmail('john.doe@example.com');
        
        $this->entityManager->persist($this->event);
        $this->entityManager->persist($this->attendee);
        $this->entityManager->flush();
    }

    public function testCreateBooking(): void
    {
        $client = static::createClient();
        $client->request('POST', '/api/bookings', [], [], [
            'CONTENT_TYPE' => 'application/json',
        ], json_encode([
            'event_id' => $this->event->getId(),
            'attendee_id' => $this->attendee->getId(),
        ]));

        $this->assertResponseStatusCodeSame(Response::HTTP_CREATED);
        $this->assertResponseHeaderSame('Content-Type', 'application/json');
        
        $responseData = json_decode($client->getResponse()->getContent(), true);
        $this->assertArrayHasKey('id', $responseData);
    }

    public function testDuplicateBooking(): void
    {
        $client = static::createClient();
        
        // First booking
        $client->request('POST', '/api/bookings', [], [], [
            'CONTENT_TYPE' => 'application/json',
        ], json_encode([
            'event_id' => $this->event->getId(),
            'attendee_id' => $this->attendee->getId(),
        ]));
        
        // Try to book again with the same attendee
        $client->request('POST', '/api/bookings', [], [], [
            'CONTENT_TYPE' => 'application/json',
        ], json_encode([
            'event_id' => $this->event->getId(),
            'attendee_id' => $this->attendee->getId(),
        ]));

        $this->assertResponseStatusCodeSame(Response::HTTP_BAD_REQUEST);
        $responseData = json_decode($client->getResponse()->getContent(), true);
        $this->assertArrayHasKey('error', $responseData);
    }

    public function testOverbooking(): void
    {
        $client = static::createClient();
        
        // Create two more attendees
        $attendee1 = new Attendee();
        $attendee1->setFirstName('Jane');
        $attendee1->setLastName('Doe');
        $attendee1->setEmail('jane.doe@example.com');
        
        $attendee2 = new Attendee();
        $attendee2->setFirstName('Bob');
        $attendee2->setLastName('Smith');
        $attendee2->setEmail('bob.smith@example.com');
        
        $this->entityManager->persist($attendee1);
        $this->entityManager->persist($attendee2);
        $this->entityManager->flush();
        
        // Book with first attendee
        $client->request('POST', '/api/bookings', [], [], [
            'CONTENT_TYPE' => 'application/json',
        ], json_encode([
            'event_id' => $this->event->getId(),
            'attendee_id' => $this->attendee->getId(),
        ]));
        
        // Book with second attendee
        $client->request('POST', '/api/bookings', [], [], [
            'CONTENT_TYPE' => 'application/json',
        ], json_encode([
            'event_id' => $this->event->getId(),
            'attendee_id' => $attendee1->getId(),
        ]));
        
        // Try to book with third attendee (should fail due to capacity)
        $client->request('POST', '/api/bookings', [], [], [
            'CONTENT_TYPE' => 'application/json',
        ], json_encode([
            'event_id' => $this->event->getId(),
            'attendee_id' => $attendee2->getId(),
        ]));

        $this->assertResponseStatusCodeSame(Response::HTTP_BAD_REQUEST);
        $responseData = json_decode($client->getResponse()->getContent(), true);
        $this->assertArrayHasKey('error', $responseData);
        $this->assertStringContainsString('full capacity', $responseData['error']);
    }

    protected function tearDown(): void
    {
        parent::tearDown();
        
        // Clean up the database
        $this->entityManager->close();
        $this->entityManager = null;
    }
}